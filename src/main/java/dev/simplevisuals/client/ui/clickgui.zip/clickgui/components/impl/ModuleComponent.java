package dev.simplevisuals.client.ui.clickgui.components.impl;

import dev.simplevisuals.modules.settings.impl.*;
import dev.simplevisuals.client.ui.clickgui.components.Component;
import dev.simplevisuals.modules.api.Module;
import dev.simplevisuals.modules.settings.Setting;
import dev.simplevisuals.modules.settings.api.Bind;
import dev.simplevisuals.client.util.animations.Animation;
import dev.simplevisuals.client.util.animations.Easing;
import dev.simplevisuals.client.util.math.MathUtils;
import dev.simplevisuals.client.util.renderer.fonts.Fonts;
import dev.simplevisuals.client.util.renderer.Render2D;
import lombok.Getter;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import dev.simplevisuals.client.managers.ThemeManager;

public class ModuleComponent extends Component {

    private final Module module;
    private boolean open;
    private boolean binding;
    private boolean showBindModeMenu;
    private boolean renderExternally;

    // координаты отображения текста бинда для хитбокса
    private float bindTextX, bindTextY, bindTextW, bindTextH;

    @Getter private final List<Component> components = new ArrayList<>();

    private final Animation hoverAnim   = new Animation(200, 1f, false, Easing.BOTH_SINE);
    private final Animation toggleAnim  = new Animation(200, 1f, false, Easing.BOTH_SINE);
    @Getter private final Animation openAnimation = new Animation(300, 1f, false, Easing.BOTH_SINE);
    private final Animation bindMenuAnimation = new Animation(200, 1f, false, Easing.BOTH_SINE);

    private static final float HEADER_HEIGHT = 18f;
    private static final float CHILD_HEIGHT  = 18f;

    public ModuleComponent(Module module) {
        super(module.getName());
        this.module = module;

        for (Setting<?> setting : module.getSettings()) {
            if (setting instanceof BooleanSetting) components.add(new BooleanComponent((BooleanSetting) setting));
            else if (setting instanceof NumberSetting) components.add(new SliderComponent((NumberSetting) setting));
            else if (setting instanceof EnumSetting) components.add(new EnumComponent((EnumSetting<?>) setting));
            else if (setting instanceof StringSetting) components.add(new StringComponent((StringSetting) setting));
            else if (setting instanceof ListSetting) components.add(new ListComponent((ListSetting) setting));
            else if (setting instanceof BindSetting) components.add(new BindComponent((BindSetting) setting));
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        boolean hovered = MathUtils.isHovered(x, y, width, HEADER_HEIGHT, mouseX, mouseY);

        hoverAnim.update(hovered || module.isToggled());
        toggleAnim.update(module.isToggled());
        openAnimation.update(open);
        bindMenuAnimation.update(showBindModeMenu);

        // фон
        Color base = new Color(0, 0, 0, 120);
        Color themeAccent = ThemeManager.getInstance().getCurrentTheme().getAccentColor();
        Color active = new Color(themeAccent.getRed(), themeAccent.getGreen(), themeAccent.getBlue(), 180);
        Color bg = lerpColor(base, active, (float) toggleAnim.getValue());

        float totalHeight = getHeight();
        Render2D.drawRoundedRect(context.getMatrices(), x, y, width, totalHeight, 4f, bg);

        // заголовок
        Color textColor = new Color(255, 255, 255, (int) (200 + 55 * hoverAnim.getValue()));
        Render2D.drawFont(context.getMatrices(), Fonts.REGULAR.getFont(8f),
                module.getName(), x + 7f, y + 4.5f, textColor);

        // биндинг — вычисляем позицию и хитбокс
        String bindText = "";
        if (binding) bindText = "Press key...";
        else if (module.getBind() != null && module.getBind().getKey() != -1)
            bindText = module.getBind().toString().replace("_", " ");

        bindTextW = bindText.isEmpty() ? 0f : Fonts.REGULAR.getWidth(bindText, 8f);
        bindTextH = 9f; // приблизительно высота текста 8f
        bindTextX = x + width - bindTextW - 6f;
        bindTextY = y + 4.5f;

        if (!bindText.isEmpty()) {
            Render2D.drawFont(context.getMatrices(), Fonts.REGULAR.getFont(8f),
                    bindText, bindTextX, bindTextY,
                    new Color(200, 200, 200, 200));
        }

        // дочерние компоненты
        if (openAnimation.getValue() > 0f && !renderExternally) {
            float childY = y + HEADER_HEIGHT;
            float visibleH = getChildrenFullHeight() * (float) openAnimation.getValue();

            // клип ограничен рамкой модуля
            context.enableScissor((int) x, (int) (y + HEADER_HEIGHT),
                    (int) (x + width), (int) (y + HEADER_HEIGHT + visibleH));

            for (Component component : components) {
                if (!component.getVisible().get()) continue;
                component.setX(x + 5f);
                component.setY(childY);
                component.setWidth(width - 10f);
                component.setHeight(CHILD_HEIGHT);
                component.render(context, mouseX, mouseY, delta);
                childY += component.getHeight() + component.getAddHeight().get();
            }

            context.disableScissor();
        }

        // Контекстное меню режима бинда (Toggle/Hold) с анимацией и галочкой
        if (bindMenuAnimation.getValue() > 0f) {
            float menuX = x + width - 90f;
            float menuY = y + HEADER_HEIGHT + 2f;
            float itemW = 80f * (float) bindMenuAnimation.getValue();
            float itemH = 12f;

            Color menuBg = new Color(20, 20, 20, (int) (220 * bindMenuAnimation.getValue()));
            Render2D.drawRoundedRect(context.getMatrices(), menuX, menuY, itemW, itemH * 2 + 4f, 3f, menuBg);

            String opt1 = "Toggle";
            String opt2 = "Hold";

            // чекбокс как в ListComponent: иконка "D" чёрная с альфой-анимацией
            boolean isToggle = module.getBind() != null && module.getBind().getMode() == Bind.Mode.TOGGLE;
            boolean isHold = module.getBind() != null && module.getBind().getMode() == Bind.Mode.HOLD;

            // Toggle row
            Render2D.drawFont(context.getMatrices(), Fonts.REGULAR.getFont(7f), opt1, menuX + 18f, menuY + 3f, new Color(255, 255, 255, (int) (255 * bindMenuAnimation.getValue())));
            Render2D.drawFont(context.getMatrices(), Fonts.ICONS.getFont(10f), "D", menuX + 6f, menuY + 3.5f,
                    new Color(0, 0, 0, (int) (255 * (isToggle ? bindMenuAnimation.getValue() : 0.0f))));

            // Hold row
            Render2D.drawFont(context.getMatrices(), Fonts.REGULAR.getFont(7f), opt2, menuX + 18f, menuY + 3f + itemH, new Color(255, 255, 255, (int) (255 * bindMenuAnimation.getValue())));
            Render2D.drawFont(context.getMatrices(), Fonts.ICONS.getFont(10f), "D", menuX + 6f, menuY + 3.5f + itemH,
                    new Color(0, 0, 0, (int) (255 * (isHold ? bindMenuAnimation.getValue() : 0.0f))));
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        boolean onHeader = MathUtils.isHovered(x, y, width, HEADER_HEIGHT, (float) mouseX, (float) mouseY);
        boolean onBindText = (!Float.isNaN(bindTextX)) && MathUtils.isHovered(bindTextX, bindTextY - 1f, bindTextW, bindTextH + 2f, (float) mouseX, (float) mouseY);

        if (onHeader) {
            // ЛКМ по тексту бинда — открыть меню режима бинда
            if (button == 0 && onBindText && !binding) {
                if (module.getBind() != null && !module.getBind().isEmpty()) {
                    showBindModeMenu = !showBindModeMenu;
                    return;
                }
            }

            if (button == 0 && !binding && !onBindText) { // ЛКМ — вкл/выкл, если не по бинд-тексту
                module.toggle();
                return;
            } else if (button == 1 && !components.isEmpty() && !binding && !renderExternally) { // ПКМ — открыть/закрыть список (только если не внешний режим)
                open = !open;
                return;
            } else if (button == 2 && !binding) { // СКМ — бинд
                binding = true;
                return;
            }
        }

        // клик по пунктам меню режима бинда
        if (showBindModeMenu) {
            float menuX = x + width - 90f;
            float menuY = y + HEADER_HEIGHT + 2f;
            float itemW = 80f;
            float itemH = 12f;
            if (MathUtils.isHovered(menuX, menuY, itemW, itemH, (float) mouseX, (float) mouseY)) {
                module.getBind().setMode(Bind.Mode.TOGGLE);
                showBindModeMenu = false;
                return;
            }
            if (MathUtils.isHovered(menuX, menuY + itemH, itemW, itemH, (float) mouseX, (float) mouseY)) {
                module.getBind().setMode(Bind.Mode.HOLD);
                showBindModeMenu = false;
                return;
            }
            // клик снаружи — закрыть меню
            if (!MathUtils.isHovered(menuX, menuY, itemW, itemH * 2f, (float) mouseX, (float) mouseY)) {
                showBindModeMenu = false;
            }
        }

        if (openAnimation.getValue() > 0f && !renderExternally) {
            for (Component component : components) component.mouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (openAnimation.getValue() > 0f && !renderExternally) {
            for (Component component : components) component.mouseReleased(mouseX, mouseY, button);
        }
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) {
                module.setBind(new Bind(-1, false)); // снять бинд
            } else {
                // сохраняем текущий режим при переназначении
                Bind.Mode mode = module.getBind() != null ? module.getBind().getMode() : Bind.Mode.TOGGLE;
                module.setBind(new Bind(keyCode, false, mode));
            }
            binding = false;
            return;
        }

        if (openAnimation.getValue() > 0f && !renderExternally) {
            for (Component component : components) component.keyPressed(keyCode, scanCode, modifiers);
        }
    }

    @Override
    public void keyReleased(int keyCode, int scanCode, int modifiers) {
        if (openAnimation.getValue() > 0f && !renderExternally) {
            for (Component component : components) component.keyReleased(keyCode, scanCode, modifiers);
        }
    }

    @Override
    public void charTyped(char chr, int modifiers) {
        if (openAnimation.getValue() > 0f && !renderExternally) {
            for (Component component : components) component.charTyped(chr, modifiers);
        }
    }

    // высота = только заголовок, если внешний рендер настроек активен
    @Override
    public float getHeight() {
        if (renderExternally) return HEADER_HEIGHT;
        return HEADER_HEIGHT + getChildrenFullHeight() * (float) openAnimation.getValue();
    }

    public float getChildrenFullHeight() {
        float h = 0f;
        for (Component c : components) {
            if (!c.getVisible().get()) continue;
            h += CHILD_HEIGHT + c.getAddHeight().get();
        }
        return h;
    }

    private static Color lerpColor(Color c1, Color c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (c1.getRed()   + (c2.getRed()   - c1.getRed())   * t);
        int g = (int) (c1.getGreen() + (c2.getGreen() - c1.getGreen()) * t);
        int b = (int) (c1.getBlue()  + (c2.getBlue()  - c1.getBlue())  * t);
        int a = (int) (c1.getAlpha() + (c2.getAlpha() - c1.getAlpha()) * t);
        return new Color(r, g, b, a);
    }
    public Module getModule() {
        return module;
    }

    public void setRenderExternally(boolean value) {
        this.renderExternally = value;
    }

    public boolean isRenderExternally() {
        return renderExternally;
    }

    public float renderSettingsExternally(DrawContext context, float contentX, float contentY, float contentW,
            float clipX, float clipY, float clipW, float clipH, int mouseX, int mouseY, float delta, float scrollY) {
        float childY = contentY - scrollY;
        float totalHeight = 0f;
        context.enableScissor((int) clipX, (int) clipY, (int) (clipX + clipW), (int) (clipY + clipH));
        for (Component component : components) {
            if (!component.getVisible().get()) continue;
            component.setX(contentX + 5f);
            component.setY(childY);
            component.setWidth(contentW - 10f);
            component.setHeight(CHILD_HEIGHT);
            component.render(context, mouseX, mouseY, delta);
            float h = component.getHeight() + component.getAddHeight().get();
            childY += h;
            totalHeight += h;
        }
        context.disableScissor();
        return totalHeight;
    }

    public void mouseClickedExternal(double mouseX, double mouseY, int button) {
        for (Component component : components) component.mouseClicked(mouseX, mouseY, button);
    }

    public void mouseReleasedExternal(double mouseX, double mouseY, int button) {
        for (Component component : components) component.mouseReleased(mouseX, mouseY, button);
    }

    public void keyPressedExternal(int keyCode, int scanCode, int modifiers) {
        for (Component component : components) component.keyPressed(keyCode, scanCode, modifiers);
    }

    public void keyReleasedExternal(int keyCode, int scanCode, int modifiers) {
        for (Component component : components) component.keyReleased(keyCode, scanCode, modifiers);
    }

    public void charTypedExternal(char chr, int modifiers) {
        for (Component component : components) component.charTyped(chr, modifiers);
    }
}
